import { Clock, ChefHat, CheckCircle, TruckIcon } from "lucide-react";
import { useState } from "react";

type OrderStatus =
  | "received"
  | "preparing"
  | "ready"
  | "gathering"
  | "serving"
  | "delivered";

interface Order {
  id: string;
  table: number;
  dishes: { name: string; quantity: number }[];
  specialInstructions: string[];
  status: OrderStatus;
  timeElapsed: number;
  priority: "normal" | "high" | "urgent";
}

const statusLabels: Record<OrderStatus, string> = {
  received: "Order Received",
  preparing: "Culinary Prep",
  ready: "Food Prepared",
  gathering: "Gathering Cutleries",
  serving: "Coming to Table",
  delivered: "Delivered",
};

const mockOrders: Order[] = [
  {
    id: "ORD-1247",
    table: 12,
    dishes: [
      { name: "Butter Chicken", quantity: 2 },
      { name: "Garlic Naan", quantity: 4 },
      { name: "Dal Makhani", quantity: 1 },
    ],
    specialInstructions: ["Less Spicy", "No Onions"],
    status: "preparing",
    timeElapsed: 8,
    priority: "high",
  },
  {
    id: "ORD-1248",
    table: 7,
    dishes: [
      { name: "Paneer Tikka", quantity: 1 },
      { name: "Veg Biryani", quantity: 2 },
    ],
    specialInstructions: ["Extra Crispy"],
    status: "received",
    timeElapsed: 2,
    priority: "normal",
  },
  {
    id: "ORD-1249",
    table: 15,
    dishes: [
      { name: "Chicken Biryani", quantity: 3 },
      { name: "Raita", quantity: 3 },
      { name: "Gulab Jamun", quantity: 2 },
    ],
    specialInstructions: ["No Peas", "Less Oil"],
    status: "ready",
    timeElapsed: 15,
    priority: "urgent",
  },
  {
    id: "ORD-1250",
    table: 3,
    dishes: [
      { name: "Masala Dosa", quantity: 2 },
      { name: "Filter Coffee", quantity: 2 },
    ],
    specialInstructions: [],
    status: "gathering",
    timeElapsed: 18,
    priority: "normal",
  },
];

export function KitchenBackend() {
  const [orders, setOrders] = useState<Order[]>(mockOrders);

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders((prev) =>
      prev.map((order) =>
        order.id === orderId ? { ...order, status: newStatus } : order
      )
    );
  };

  const getStatusColor = (status: OrderStatus) => {
    const colors: Record<OrderStatus, string> = {
      received: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
      preparing: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
      ready: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
      gathering: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
      serving: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400",
      delivered: "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400",
    };
    return colors[status];
  };

  const getPriorityColor = (priority: Order["priority"]) => {
    const colors = {
      normal: "bg-gray-200 dark:bg-gray-700",
      high: "bg-orange-500",
      urgent: "bg-red-500",
    };
    return colors[priority];
  };

  const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
    const flow: OrderStatus[] = [
      "received",
      "preparing",
      "ready",
      "gathering",
      "serving",
      "delivered",
    ];
    const currentIndex = flow.indexOf(currentStatus);
    return currentIndex < flow.length - 1 ? flow[currentIndex + 1] : null;
  };

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1>Kitchen Backend</h1>
          <p className="text-muted-foreground mt-1">
            Live order management with 2-second readability
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="bg-card rounded-lg px-4 py-2 border border-border">
            <p className="text-sm text-muted-foreground">Active Orders</p>
            <p className="text-2xl font-bold">{orders.length}</p>
          </div>
          <div className="bg-card rounded-lg px-4 py-2 border border-border">
            <p className="text-sm text-muted-foreground">Avg. Prep Time</p>
            <p className="text-2xl font-bold">12 min</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {orders.map((order) => (
          <div
            key={order.id}
            className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="flex items-center gap-4 p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border">
              <div
                className={`w-2 h-16 rounded-full ${getPriorityColor(
                  order.priority
                )}`}
              />

              <div className="flex-1">
                <div className="flex items-center gap-4 mb-2">
                  <h2 className="font-bold">Order {order.id}</h2>
                  <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
                    Table {order.table}
                  </span>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(
                      order.status
                    )}`}
                  >
                    {statusLabels[order.status]}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{order.timeElapsed} min elapsed</span>
                  {order.timeElapsed > 15 && (
                    <span className="text-red-600 dark:text-red-400 font-medium">
                      • Running late
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="mb-3 flex items-center gap-2">
                    <ChefHat className="w-4 h-4 text-primary" />
                    Dishes Ordered
                  </h4>
                  <div className="space-y-2">
                    {order.dishes.map((dish, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-3 bg-accent/30 rounded-lg"
                      >
                        <span className="font-medium">{dish.name}</span>
                        <span className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-sm font-semibold">
                          x{dish.quantity}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {order.specialInstructions.length > 0 && (
                  <div>
                    <h4 className="mb-3">Special Instructions</h4>
                    <div className="flex flex-wrap gap-2">
                      {order.specialInstructions.map((instruction, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-2 bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400 rounded-lg text-sm font-medium border border-yellow-300 dark:border-yellow-700"
                        >
                          {instruction}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="border-t border-border pt-6">
                <h4 className="mb-3">Workflow Actions</h4>
                <div className="flex flex-wrap gap-3">
                  {(
                    [
                      "received",
                      "preparing",
                      "ready",
                      "gathering",
                      "serving",
                      "delivered",
                    ] as OrderStatus[]
                  ).map((status) => {
                    const isActive = order.status === status;
                    const isPast =
                      [
                        "received",
                        "preparing",
                        "ready",
                        "gathering",
                        "serving",
                        "delivered",
                      ].indexOf(status) <
                      [
                        "received",
                        "preparing",
                        "ready",
                        "gathering",
                        "serving",
                        "delivered",
                      ].indexOf(order.status);

                    return (
                      <button
                        key={status}
                        onClick={() => updateOrderStatus(order.id, status)}
                        className={`px-6 py-3 rounded-lg font-medium transition-all ${
                          isActive
                            ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                            : isPast
                            ? "bg-accent/50 text-accent-foreground opacity-60"
                            : "bg-accent text-accent-foreground hover:bg-accent/70"
                        }`}
                      >
                        {statusLabels[status]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {getNextStatus(order.status) && (
                <button
                  onClick={() => {
                    const next = getNextStatus(order.status);
                    if (next) updateOrderStatus(order.id, next);
                  }}
                  className="mt-4 w-full py-4 bg-gradient-to-r from-primary to-accent text-white rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                >
                  <CheckCircle className="w-5 h-5" />
                  Advance to {statusLabels[getNextStatus(order.status)!]}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="mb-4">Today's Stats</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
              <span className="text-sm">Orders Completed</span>
              <span className="text-xl font-bold">87</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
              <span className="text-sm">Avg. Prep Time</span>
              <span className="text-xl font-bold">12 min</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-accent/30 rounded-lg">
              <span className="text-sm">On-Time Rate</span>
              <span className="text-xl font-bold text-green-600 dark:text-green-400">
                94%
              </span>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="mb-4">Popular Items Today</h3>
          <div className="space-y-3">
            {[
              { name: "Butter Chicken", count: 23 },
              { name: "Biryani", count: 19 },
              { name: "Paneer Tikka", count: 15 },
            ].map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 bg-primary/5 rounded-lg"
              >
                <span className="text-sm font-medium">{item.name}</span>
                <span className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                  {item.count}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="mb-4">Kitchen Alerts</h3>
          <div className="space-y-3">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400 rounded-lg text-sm">
              <p className="font-medium">2 orders running late</p>
              <p className="text-xs mt-1">Table 12, Table 15</p>
            </div>
            <div className="p-3 bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 rounded-lg text-sm">
              <p className="font-medium">All stations operational</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
