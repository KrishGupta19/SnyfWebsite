import { TrendingUp, Users, ShoppingBag, Activity } from "lucide-react";
import { LineChart, Line, ResponsiveContainer } from "recharts";

const sparklineData = [
  { value: 30 },
  { value: 40 },
  { value: 35 },
  { value: 50 },
  { value: 49 },
  { value: 60 },
  { value: 70 },
  { value: 65 },
  { value: 75 },
];

const metrics = [
  {
    label: "Total Revenue",
    value: "₹8,45,230",
    change: "+12.5%",
    trend: "up",
    icon: TrendingUp,
  },
  {
    label: "Weekly Revenue",
    value: "₹1,24,500",
    change: "+8.2%",
    trend: "up",
    icon: TrendingUp,
  },
  {
    label: "Monthly Revenue",
    value: "₹5,67,890",
    change: "+15.4%",
    trend: "up",
    icon: TrendingUp,
  },
  {
    label: "Total Users Till Date",
    value: "3,245",
    change: "+23.1%",
    trend: "up",
    icon: Users,
  },
  {
    label: "Repeat Customer %",
    value: "68.5%",
    change: "+5.2%",
    trend: "up",
    icon: Users,
  },
  {
    label: "Active Orders",
    value: "18",
    change: "Live",
    trend: "neutral",
    icon: ShoppingBag,
  },
  {
    label: "Occupancy Insights",
    value: "72%",
    change: "+4.8%",
    trend: "up",
    icon: Activity,
  },
  {
    label: "Trending Score",
    value: "8.9/10",
    change: "+0.3",
    trend: "up",
    icon: Activity,
  },
];

export function Dashboard() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h1>Dashboard Overview</h1>
        <p className="text-muted-foreground mt-1">
          Real-time insights into your café's performance
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <div
            key={index}
            className="bg-card rounded-2xl p-6 border border-border shadow-sm hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <metric.icon className="w-5 h-5 text-primary" />
              </div>
              <span
                className={`text-xs px-2 py-1 rounded-full ${
                  metric.trend === "up"
                    ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                    : "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
                }`}
              >
                {metric.change}
              </span>
            </div>

            <h3 className="text-3xl font-semibold mb-1">{metric.value}</h3>
            <p className="text-sm text-muted-foreground">{metric.label}</p>

            <div className="mt-4 h-12 -mb-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sparklineData}>
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="var(--color-primary)"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {[
              {
                action: "New order received",
                details: "Table 12 - ₹1,850",
                time: "2 min ago",
              },
              {
                action: "Customer checked in",
                details: "Repeat visitor - 5th visit",
                time: "8 min ago",
              },
              {
                action: "Order completed",
                details: "Table 7 - ₹2,340",
                time: "15 min ago",
              },
              {
                action: "New reservation",
                details: "4 people - 7:30 PM",
                time: "23 min ago",
              },
            ].map((activity, idx) => (
              <div
                key={idx}
                className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent/50 transition-colors"
              >
                <div className="w-2 h-2 bg-accent rounded-full mt-2" />
                <div className="flex-1">
                  <p className="text-sm font-medium">{activity.action}</p>
                  <p className="text-xs text-muted-foreground">
                    {activity.details}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {activity.time}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 border border-border">
          <h3 className="mb-4">Peak Hours Today</h3>
          <div className="space-y-4">
            {[
              { time: "12:00 PM - 2:00 PM", occupancy: 92, revenue: "₹45,600" },
              { time: "7:00 PM - 9:00 PM", occupancy: 88, revenue: "₹52,300" },
              { time: "9:00 AM - 11:00 AM", occupancy: 65, revenue: "₹28,900" },
              { time: "4:00 PM - 6:00 PM", occupancy: 58, revenue: "₹22,400" },
            ].map((slot, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>{slot.time}</span>
                  <span className="font-medium">{slot.revenue}</span>
                </div>
                <div className="h-2 bg-accent/30 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                    style={{ width: `${slot.occupancy}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  {slot.occupancy}% occupied
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
