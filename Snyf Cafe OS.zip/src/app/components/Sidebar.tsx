import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  TrendingUp,
  Users,
  Megaphone,
  Target,
  QrCode,
  Gift,
  Settings,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useState } from "react";

const navItems = [
  { path: "/", icon: LayoutDashboard, label: "Overview" },
  { path: "/revenue", icon: TrendingUp, label: "Revenue Analytics" },
  { path: "/customers", icon: Users, label: "Customer Insights" },
  { path: "/campaigns", icon: Megaphone, label: "Campaign Engine" },
  { path: "/growth", icon: Target, label: "Growth Plans" },
  { path: "/qr", icon: QrCode, label: "QR Analytics" },
  { path: "/rewards", icon: Gift, label: "Rewards" },
  { path: "/kitchen", icon: Settings, label: "Kitchen Backend" },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={`${
        collapsed ? "w-20" : "w-64"
      } h-screen bg-card border-r border-border transition-all duration-300 flex flex-col`}
    >
      <div className="p-6 flex items-center justify-between border-b border-border">
        {!collapsed && (
          <h1 className="font-semibold">
            <span className="text-primary">SNYF</span> Café OS
          </h1>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-accent rounded-lg transition-colors"
        >
          {collapsed ? (
            <ChevronRight className="w-5 h-5" />
          ) : (
            <ChevronLeft className="w-5 h-5" />
          )}
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                  : "hover:bg-accent text-foreground"
              }`
            }
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <span className="text-xs font-semibold text-white">SC</span>
          </div>
          {!collapsed && (
            <div className="flex-1">
              <p className="text-sm font-medium">SNYF Café</p>
              <p className="text-xs text-muted-foreground">Premium</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
