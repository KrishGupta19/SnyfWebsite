import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { Dashboard } from "./pages/Dashboard";
import { Revenue } from "./pages/Revenue";
import { CustomerInsights } from "./pages/CustomerInsights";
import { GrowthPlans } from "./pages/GrowthPlans";
import { KitchenBackend } from "./pages/KitchenBackend";
import { Placeholder } from "./pages/Placeholder";

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex h-screen overflow-hidden bg-background">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <TopBar />
          <main className="flex-1 overflow-y-auto">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/revenue" element={<Revenue />} />
              <Route path="/customers" element={<CustomerInsights />} />
              <Route path="/growth" element={<GrowthPlans />} />
              <Route path="/kitchen" element={<KitchenBackend />} />
              <Route
                path="/campaigns"
                element={
                  <Placeholder
                    title="Campaign Engine"
                    description="Campaign management features coming soon"
                  />
                }
              />
              <Route
                path="/qr"
                element={
                  <Placeholder
                    title="QR Analytics"
                    description="QR code tracking and analytics coming soon"
                  />
                }
              />
              <Route
                path="/rewards"
                element={
                  <Placeholder
                    title="Rewards Program"
                    description="Customer rewards and loyalty features coming soon"
                  />
                }
              />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}